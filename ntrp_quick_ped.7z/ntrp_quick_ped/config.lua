Config = {}

Config.UseQuickPed = true   -- Use this Script to Spawn First Ped when spawning in | true or false
Config.StartModel = 'A_M_M_ARMTOWNFOLK_01'  -- Ped you want to spawn first in when you log in | Config.UseQuickPed = true
